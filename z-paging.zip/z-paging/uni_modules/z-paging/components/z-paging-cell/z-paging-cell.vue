<!-- z-paging -->
<!-- github地址:https://github.com/SmileZXLee/uni-z-paging -->
<!-- dcloud地址:https://ext.dcloud.net.cn/plugin?id=3935 -->
<!-- 反馈QQ群：790460711 -->

<!-- 滑动切换选项卡swiper，此组件支持easycom规范，可以在项目中直接引用 -->
<template>
	<view :style="[{height:fianlHeight}]" id="z-paging-cell">
		<view v-if="finalShow">
			<slot />
		</view>
	</view>
</template>

<script>
	export default {
		name: "z-paging-cell",
		data() {
			return {
				height: '',
				finalShow: true
			};
		},
		props: {
			range: {
				type: Array,
				default: []
			},
			index: {
				type: Number,
				default: 0
			},
		},
		computed: {
		   show(){
			   if(this.range.length !== 2){
				   return true;
			   }
			   if(this.index >= this.range[0] && this.index <= this.range[1]){
				   return true;
			   }
			   return false;
		   },
		   fianlHeight(){
			   if(this.finalShow){
				   return 'auto';
			   }
			   return this.height;
		   }
		},
		watch: {
			show(newVal){
			   if(!newVal) {
				   this.$nextTick(()=>{
					   setTimeout(()=> {
						   const query = uni.createSelectorQuery().in(this);
						   query.select('#z-paging-cell').boundingClientRect(data => {
							 this.height = data.height + 'px';
							 this.finalShow = newVal;
						   }).exec();
					   }, 100);
				   })
			   }else{
				   this.finalShow = newVal;
			   }
			},
			finalShow(newVal){
				
			}
		},
		mounted(){
			this.$nextTick(()=>{
				setTimeout(()=> {
					const query = uni.createSelectorQuery().in(this);
					query.select('#z-paging-cell').boundingClientRect(data => {
					  //this.height = data.height + 'px';
					  if(!this.show){
						  this.finalShow = false;
					  }
					}).exec();
				}, 10);
			})
		},
	}
</script>

<style scoped>
	
</style>
